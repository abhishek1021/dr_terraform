import json
import utils

def lambda_handler(event, context):
    return utils.format_response(200, {'message': 'Hello from Lambda with layer!'})
